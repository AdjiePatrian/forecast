# dashboard/callbacks/compare_callbacks.py
from dash import Input, Output, State, html, dcc
from dash.exceptions import PreventUpdate
import plotly.graph_objs as go
import pandas as pd
from flask_login import current_user
from datetime import datetime
import dash
import json

from auth.models import get_db_session, ForecastResult, RealDataInput, get_user_by_username
from telegram_bot import send_telegram_message_to_all


# =========================================
# 🔧 Utility Function
# =========================================
def _normalize_forecast_df(df):
    """Normalize forecast DataFrame agar punya timestamp & timestamp_str."""
    if df is None:
        return pd.DataFrame()
    df = pd.DataFrame(df) if isinstance(df, (list, dict)) else df.copy()
    if df.empty:
        return df

    if "timestamp" in df.columns:
        df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    elif "timestamp_str" in df.columns:
        df["timestamp"] = pd.to_datetime(df["timestamp_str"], errors="coerce")
    else:
        possible = [c for c in df.columns if "date" in c.lower() or "time" in c.lower()]
        if possible:
            df["timestamp"] = pd.to_datetime(df[possible[0]], errors="coerce")

    df["timestamp_str"] = df["timestamp"].dt.strftime("%Y-%m-%d")
    return df


# =========================================
# 🧠 REGISTER CALLBACKS
# =========================================
def register_callbacks(app):
    print("[DEBUG] ✅ compare_callbacks.register_callbacks aktif")

    # ======================================================
    # 1️⃣ Auto Load Forecast dari DB kalau localStorage kosong
    # ======================================================
    @app.callback(
        Output("forecast-memory", "data", allow_duplicate=True),
        Output("forecast-metadata", "data", allow_duplicate=True),
        Input("url", "pathname"),
        prevent_initial_call=True,
    )
    def load_forecast_from_db(pathname):
        """Load forecast terakhir user dari DB jika halaman Compare dibuka."""
        if pathname != "/compare":
            raise PreventUpdate

        try:
            with get_db_session() as db:
                user = get_user_by_username(current_user.username)
                if not user:
                    raise PreventUpdate

                last_forecast = (
                    db.query(ForecastResult)
                    .filter(ForecastResult.user_id == user.id)
                    .order_by(ForecastResult.created_at.desc())
                    .first()
                )
                if not last_forecast:
                    print("[DEBUG] Tidak ada forecast tersimpan di DB untuk user ini.")
                    raise PreventUpdate

                print(f"[DEBUG] Auto-load forecast ID={last_forecast.id} dari database.")
                return (
                    last_forecast.forecast_output,
                    {
                        "model_name": last_forecast.model_name,
                        "uploaded_filename": last_forecast.uploaded_filename,
                    },
                )

        except Exception as e:
            print(f"[ERROR] load_forecast_from_db gagal: {e}")
            raise PreventUpdate

    # ======================================================
    # 2️⃣ Tampilkan grafik forecast dari localStorage / DB
    # ======================================================
    @app.callback(
        Output("compare-chart", "figure"),
        Output("forecast-alert", "children"),
        Input("forecast-memory", "data"),
        prevent_initial_call=False,
    )
    def display_forecast_chart(stored_forecast):
        forecast_df = _normalize_forecast_df(stored_forecast)
        if forecast_df.empty:
            alert = html.Div(
                [
                    html.I(className="bi bi-exclamation-circle-fill me-2"),
                    "Belum ada hasil forecasting tersimpan di browser / database.",
                    html.Br(),
                    "Silakan jalankan Forecast dulu di halaman Forecasting.",
                ],
                style={"color": "orange"},
            )
            fig = go.Figure(layout={"template": "plotly_white"})
            fig.update_layout(title="Forecast vs Real Data (Kosong)")
            return fig, alert

        fig = go.Figure(layout={"template": "plotly_white"})
        forecast_sorted = forecast_df.sort_values("timestamp")

        if {"p10", "p90"} <= set(forecast_sorted.columns):
            fig.add_trace(
                go.Scatter(
                    x=forecast_sorted["timestamp"],
                    y=forecast_sorted["p90"],
                    line=dict(color="rgba(0,0,0,0)"),
                    showlegend=False,
                )
            )
            fig.add_trace(
                go.Scatter(
                    x=forecast_sorted["timestamp"],
                    y=forecast_sorted["p10"],
                    fill="tonexty",
                    fillcolor="rgba(33,150,243,0.16)",
                    name="P10–P90 Interval",
                )
            )

        if "mean" in forecast_sorted.columns:
            fig.add_trace(
                go.Scatter(
                    x=forecast_sorted["timestamp"],
                    y=forecast_sorted["mean"],
                    mode="lines+markers",
                    name="Forecast (mean)",
                    line=dict(width=3),
                )
            )

        fig.update_layout(title="Forecast vs Real Data", xaxis_title="Tanggal", yaxis_title="Nilai")
        return fig, None

    # ======================================================
    # 3️⃣ Tambahkan Real Data + Simpan ke DB
    # ======================================================
    @app.callback(
        Output("real-data-table", "data"),
        Output("real-data-table", "style_data_conditional"),
        Output("alert-select", "options"),
        Output("compare-chart", "figure", allow_duplicate=True),
        Input("add-real-btn", "n_clicks"),
        State("real-date", "date"),
        State("real-value", "value"),
        State("real-data-table", "data"),
        State("forecast-memory", "data"),
        State("forecast-metadata", "data"),
        prevent_initial_call=True,
    )
    def add_real_data(n_clicks, real_date, real_value, current_data, stored_forecast, forecast_metadata):
        if not n_clicks or not real_date or real_value is None:
            raise PreventUpdate

        if current_data is None:
            current_data = []

        forecast_df = _normalize_forecast_df(stored_forecast)
        if forecast_df.empty:
            raise PreventUpdate

        parsed_date = pd.to_datetime(real_date).strftime("%Y-%m-%d")
        if not any(row.get("date") == parsed_date for row in current_data):
            current_data.append({"date": parsed_date, "value": real_value})

        # Gabungkan forecast & real data
        for row in current_data:
            pred = forecast_df[forecast_df["timestamp_str"] == row["date"]]
            if not pred.empty:
                first = pred.iloc[0]
                mean_val = float(first.get("mean", None)) if pd.notna(first.get("mean", None)) else None
                p10 = float(first.get("p10", None)) if pd.notna(first.get("p10", None)) else None
                p90 = float(first.get("p90", None)) if pd.notna(first.get("p90", None)) else None

                if mean_val is not None:
                    row["forecast"] = round(mean_val, 3)
                    row["error"] = round(row["value"] - mean_val, 3)
                else:
                    row["forecast"], row["error"] = "-", "-"

                if all(v is not None for v in [p10, p90, mean_val]):
                    row["p10"], row["p90"] = p10, p90
                    row["anomaly"] = "Yes" if (row["value"] < p10 or row["value"] > p90) else ""
                else:
                    row.update({"p10": "-", "p90": "-", "anomaly": ""})
            else:
                row.update({"forecast": "-", "error": "-", "p10": "-", "p90": "-", "anomaly": ""})

        # 💾 Simpan ke database
        try:
            with get_db_session() as db:
                user = get_user_by_username(current_user.username)
                if not user:
                    raise PreventUpdate

                forecast_entry = ForecastResult(
                    user_id=user.id,
                    model_name=forecast_metadata.get("model_name", "unknown"),
                    uploaded_filename=forecast_metadata.get("uploaded_filename", "unknown.csv"),
                    forecast_output=stored_forecast,
                    created_at=datetime.now(),
                )
                db.add(forecast_entry)
                db.flush()

                real_entry = RealDataInput(
                    forecast_id=forecast_entry.id,
                    real_data=current_data,
                    alert_sent=False,
                    anomalies_summary=None,
                    created_at=datetime.now(),
                )
                db.add(real_entry)
                db.commit()

        except Exception as e:
            print(f"[ERROR] Gagal menyimpan ke DB: {e}")

        # Style untuk highlight anomali
        style_data_conditional = [
            {"if": {"row_index": i}, "backgroundColor": "#ffdddd", "fontWeight": "600"}
            for i, r in enumerate(current_data)
            if r.get("anomaly") == "Yes"
        ]

        # Chart update
        fig = go.Figure(layout={"template": "plotly_white"})
        if {"p10", "p90"} <= set(forecast_df.columns):
            fig.add_trace(go.Scatter(x=forecast_df["timestamp"], y=forecast_df["p90"], line=dict(color="rgba(0,0,0,0)")))
            fig.add_trace(
                go.Scatter(
                    x=forecast_df["timestamp"],
                    y=forecast_df["p10"],
                    fill="tonexty",
                    fillcolor="rgba(33,150,243,0.16)",
                    name="P10–P90 Interval",
                )
            )
        if "mean" in forecast_df.columns:
            fig.add_trace(
                go.Scatter(x=forecast_df["timestamp"], y=forecast_df["mean"], mode="lines+markers", name="Forecast (mean)")
            )
        if current_data:
            fig.add_trace(
                go.Scatter(
                    x=[r["date"] for r in current_data],
                    y=[r["value"] for r in current_data],
                    mode="markers+text",
                    name="Real Data",
                    marker=dict(color=["red" if r.get("anomaly") == "Yes" else "green" for r in current_data]),
                )
            )

        return current_data, style_data_conditional, [
            {"label": f"{r['date']} — {r['value']}", "value": r["date"]} for r in current_data
        ], fig

    # ======================================================
    # 4️⃣ Tombol Reset Semua
    # ======================================================
    @app.callback(
        Output("confirm-reset-dialog", "displayed"),
        Input("reset-compare-btn", "n_clicks"),
        prevent_initial_call=True,
    )
    def show_reset_confirm(n):
        return True

    @app.callback(
        Output("real-data-table", "data", allow_duplicate=True),
        Output("compare-chart", "figure", allow_duplicate=True),
        Output("alert-select", "options", allow_duplicate=True),
        Output("forecast-alert", "children", allow_duplicate=True),
        Output("forecast-memory", "clear_data", allow_duplicate=True),
        Output("forecast-metadata", "clear_data", allow_duplicate=True),
        Input("confirm-reset-dialog", "submit_n_clicks"),
        prevent_initial_call=True,
    )
    def reset_compare_data(confirm_clicks):
        if not confirm_clicks:
            raise PreventUpdate

        try:
            with get_db_session() as db:
                user = get_user_by_username(current_user.username)
                forecasts = db.query(ForecastResult).filter(ForecastResult.user_id == user.id).all()
                for f in forecasts:
                    db.query(RealDataInput).filter(RealDataInput.forecast_id == f.id).delete()
                    db.delete(f)
                db.commit()

            alert = html.Div("✅ Semua data forecast & real berhasil dihapus. Anda bisa memulai forecasting baru.",
                             style={"color": "green"})
            empty_fig = go.Figure(layout={"template": "plotly_white", "title": "Forecast vs Real Data"})
            return [], empty_fig, [], alert, True, True

        except Exception as e:
            alert = html.Div(f"❌ Gagal menghapus data: {e}", style={"color": "red"})
            return dash.no_update, dash.no_update, dash.no_update, alert, dash.no_update, dash.no_update
